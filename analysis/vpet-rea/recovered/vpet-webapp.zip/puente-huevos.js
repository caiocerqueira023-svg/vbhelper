// (2026-11-12) Puente de las páginas de huevos (maquetas 3D aprobadas) con DBT Link: conexión real al A-Com / BTCom, lectura del vpet,
// huevos abiertos guardados en el teléfono y el huevo elegido = el vpet nuevo (uno por tipo de vpet: uno del DM20 y uno del DMX).
(function () {
  const A = window.Android || null, TIPO = window.VPET_TIPO, D = VPET[TIPO], NOMV = D.nombre;
  const leerJ = (k, f) => { try { const s = A ? A.leer(k) : localStorage.getItem(k); const v = s ? JSON.parse(s) : null; return v == null ? f : v } catch (e) { return f } };
  const guardarJ = (k, v) => { const s = JSON.stringify(v); try { A ? A.guardar(k, s) : localStorage.setItem(k, s) } catch (e) { } };
  const spr = (k, n) => VPET.spr[k] ? VPET.spr[k].replace("{n}", n || 0) : "";
  // huevos que ya abriste con lecturas anteriores
  abiertos.clear(); leerJ("vpet-abiertos-" + TIPO, []).forEach(x => abiertos.add(x));
  let leido = false, conectado = false, via = leerJ("vpet-modo", "usb");
  idx = Math.max(0, HUEVOS.findIndex(h => abiertos.has(h[0]))); pos = idx; ang = angObj = -pos * PASO;

  // ---- pantalla 1: conexión (A-Com USB o BTCom) + lectura ----
  const p1 = $("p1"), est = $("estadoCon"), bot = $("conectar");
  const atras = document.createElement("button"); atras.className = "atras"; atras.textContent = "‹"; atras.setAttribute("aria-label", "Volver");
  atras.onclick = () => { try { LECTOR.parar() } catch (e) { } if (A) { A.desconectar(); A.cerrar() } else location.href = "inicio.html" }; $("tel").appendChild(atras);
  const modos = document.createElement("div"); modos.className = "modos";
  modos.innerHTML = '<button type="button" data-m="usb">🔌 A-Com (USB)</button><button type="button" data-m="bt">📶 BTCom</button>';
  bot.parentNode.insertBefore(modos, bot);
  const mon = document.createElement("div"); mon.className = "mon"; const verMon = document.createElement("button"); verMon.className = "vermon"; verMon.textContent = "Ver lo que llega del A-Com";
  verMon.onclick = () => mon.classList.toggle("ver"); bot.parentNode.insertBefore(verMon, bot); bot.parentNode.insertBefore(mon, bot);
  const monitor = t => { mon.textContent += t + "\n"; if (mon.textContent.length > 6000) mon.textContent = mon.textContent.slice(-4000); mon.scrollTop = mon.scrollHeight };
  function pintarModo() { modos.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.m === via))); bot.textContent = conectado ? "Leer mi " + NOMV : via === "usb" ? "Conectar el A-Com" : "Buscar el BTCom" }
  modos.querySelectorAll("button").forEach(b => b.onclick = () => { if (b.dataset.m === via) return; via = b.dataset.m; guardarJ("vpet-modo", via); if (conectado && A) A.desconectar(); conectado = false; pintarModo();
    est.textContent = via === "usb" ? "Conecta el A-Com al teléfono con el cable OTG." : "Prende tu BTCom; lo busco por Bluetooth." });
  // (2026-11-12, el usuario: «mejora la conexión con el A-Com, hazla más fluida») al conectar EMPIEZA A LEER SOLO: basta con entrar a BATTLE en el vpet
  let leyendo = false;
  window.vpetEstado = e => { const antes = conectado; conectado = !!e.ok; monitor("[" + e.msg + "]"); est.textContent = e.msg; bot.disabled = false; pintarModo()
    if (conectado && !antes && !leyendo) setTimeout(() => { if (conectado && !leyendo) leer() }, 150);
    if (!conectado && leyendo) { leyendo = false; try { LECTOR.parar() } catch (x) { } clearInterval(tAcom); pintarAcom(0) } };
  // el A-Com se enchufó con la pantalla abierta: se conecta solo
  window.vpetUsb = () => { if (via === "usb" && !conectado && A) { est.textContent = "Abriendo el A-Com…"; A.conectar("usb") } };
  pintarModo(); est.textContent = "Pon tu " + NOMV + " en modo batalla. " + (via === "usb" ? "Conecta el A-Com con el cable OTG." : "Prende tu BTCom.");
  let tAcom = null;
  bot.onclick = () => {
    if (!A) { est.textContent = "Ábrelo desde DBT Link para conectar el vpet."; return }
    if (!conectado) { bot.disabled = true; est.textContent = via === "usb" ? "Abriendo el A-Com…" : "Buscando el BTCom…"; A.conectar(via); return }
    if (leyendo) { leyendo = false; LECTOR.parar(); clearInterval(tAcom); pintarAcom(0); pintarModo(); est.textContent = "Lectura pausada. Toca para volver a leer."; return }
    leer() };
  function leer() {
    leyendo = true; son("escanear", .8); bot.textContent = "Leyendo… (toca para pausar)"; est.textContent = "Listo: ahora en tu " + NOMV + " entra a BATTLE y conecta. No lo muevas.";
    let k = 0; clearInterval(tAcom); tAcom = setInterval(() => pintarAcom(++k), 90);
    LECTOR.empezar(TIPO, {
      monitor, progreso: p => { if (p > 10) est.textContent = "Leyendo tu " + NOMV + "… " + Math.round(p) + " %" },
      falla: m => { leyendo = false; clearInterval(tAcom); pintarAcom(0); bot.disabled = false; pintarModo(); est.textContent = m },
      listo: d => { leyendo = false; clearInterval(tAcom); pintarAcom(1); son("exito", .8); bot.disabled = false; pintarModo(); A.vibrar(60); resultado(d) } });
  }
  // al abrir la pantalla con el A-Com: se intenta conectar solo (si no está enchufado, quedan las instrucciones)
  if (A && via === "usb") setTimeout(() => { if (!conectado) { est.textContent = "Buscando el A-Com…"; A.conectar("usb") } }, 600);
  function resultado(d) {
    const clave = TIPO === "dm20" ? "i" + d.indice : "s" + d.set + "i" + d.indice, dg = D.digi[clave];
    const nuevos = [];
    if (TIPO === "dm20") { D.abre.siempre.forEach(x => nuevos.push(x)); for (const [h, ix] of Object.entries(D.abre.porIndice)) if (ix.includes(d.indice)) nuevos.push(h) }
    else { const hv = D.abre.porVersion[d.version]; if (hv) nuevos.push(hv); if (d.set === 2 && D.abre.kera.includes(d.indice)) nuevos.push("ogu") }
    const antes = new Set(abiertos); nuevos.forEach(x => abiertos.add(x)); guardarJ("vpet-abiertos-" + TIPO, [...abiertos]); leido = true;
    $("lectura").hidden = false; $("lecImg").src = dg ? spr(dg.s) : ""; $("lecN").textContent = dg ? dg.n : "Digimon n.º " + d.indice;
    $("lecT").textContent = NOMV + " · " + (D.ver[d.version] || "versión " + d.version) + (dg ? " · " + VPET.etapas[dg.e] : "");
    const recien = nuevos.filter(x => !antes.has(x));
    est.textContent = recien.length ? "¡Leído! Se abrieron " + recien.length + " huevo" + (recien.length > 1 ? "s" : "") + " nuevo" + (recien.length > 1 ? "s" : "") + "." : nuevos.length ? "¡Leído! Elige tu huevo." : "Leído, pero este Digimon no abre huevos.";
    const pref = nuevos.filter(x => HUEVOS.find(h => h[0] === x && h[2] !== "normal")), elegido = recien.find(x => pref.includes(x)) || pref[0] || recien[0] || nuevos[0];
    const ir = HUEVOS.findIndex(h => h[0] === elegido); idx = ir >= 0 ? ir : 0; pos = idx; ang = angObj = -pos * PASO;
    if (!nuevos.length) return;
    setTimeout(() => { modo = "carrusel"; anilloG.visible = true; ver(1); girar() }, 1300);
  }

  // ---- pantalla 2: elegir (uno por vpet; si ya tienes uno vivo, pide un segundo toque) ----
  const actual = () => leerJ("vpet-" + TIPO, null);
  let confirmar = 0;
  const girarOrig = girar; girar = function () { girarOrig(); confirmar = 0; const a = actual(), h = HUEVOS[idx];
    if (abiertos.has(h[0]) && a && !a.muerto) $("elegir").textContent = "Cambiar mi " + NOMV + " por este huevo" };
  $("elegir").onclick = () => {
    const h = HUEVOS[idx]; if (!abiertos.has(h[0])) return;
    if (!leido) { $("elegir").textContent = "Primero lee tu " + NOMV; return }
    const a = actual(); if (a && !a.muerto && confirmar < 1) { confirmar++; const dn = a.idx && D.digi[a.idx] ? D.digi[a.idx].n : "tu Digimon"; $("elegir").textContent = "Toca otra vez: se va " + dn; return }
    son("elegir", .8); son("etapa", .7, 1, .15); eclosion(h);
    const H = D.huevos[h[0]], et0 = H.etapas.findIndex(e => e.length);
    const ahora = Date.now();
    guardarJ("vpet-" + TIPO, { tipo: TIPO, huevo: h[0], nombreHuevo: h[1], color: h[3], idx: H.etapas[et0][0], etapa: et0, nace: ahora, ultimo: ahora, enEtapa: 0, hambre: 2, fuerza: 2, esfuerzo: 0, entrenos: 0, peso: 5,
      errores: 0, sobre: 0, caca: 0, herido: false, heridas: 0, duerme: false, luz: true, sinHambre: 0, heridoDesde: 0, llamadas: {}, historia: [H.etapas[et0][0]], activo: true, muerto: false });
    // nace como tu compañero (el del widget): el otro vpet queda congelado
    for (const t of ["dm20", "dmx"]) if (t !== TIPO) { const o = leerJ("vpet-" + t, null); if (o && o.activo) { o.activo = false; guardarJ("vpet-" + t, o) } }
    if (A) { if (A.compa) A.compa(TIPO); A.vibrar(40) }
  };
  $("otra").textContent = "Ir a mi " + NOMV; $("otra").onclick = () => location.href = "pantalla.html?tipo=" + TIPO;
  document.querySelector(".nota-hielo b") && (document.querySelector(".nota-hielo b").textContent = "Solo crece si es tu compañero.");
  ver(0); girar();
})();
